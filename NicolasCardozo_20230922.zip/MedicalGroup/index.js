var http = require('http');
var Home = require('./home');
var Consulta = require('./consultas');
var CadastroMedico = require('./cadastrom');
var CadastroCliente = require('./cadastroc');
var Login = require('./login');
http.createServer( function (req,res) {
res.writeHead(200, {'content-Type': 'text/html'});
res.write(Home.Home()+ "\n" + CadastroCliente.CadastroCliente()+ "\n"+  CadastroMedico.CadastroMedico()+ "\n" + Login.Login()+ "\n" + Consulta.Consulta());
res.end();
}).listen(5018)
