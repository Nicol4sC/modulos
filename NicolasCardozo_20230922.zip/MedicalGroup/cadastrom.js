exports.CadastroMedico = function () {
return ("Cadastro Medico");
}
