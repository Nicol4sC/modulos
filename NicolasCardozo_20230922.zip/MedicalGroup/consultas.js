exports.Consulta = function () {
return ("Consultas");
}

