exports.CadastroCliente = function () {
return ("Cadastro Cliente");
}

